/**
 * 
 */
/**
 * @author Administrator
 *
 */
package edu.hust.smartcommunity.paginator;