package com.smartcommunity.mapper;

import com.smartcommunity.pojo.TestPojo;

public interface ITestMapper {

	public java.util.List<TestPojo> getTestInfo();
}
