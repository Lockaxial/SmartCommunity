/**
 * 数据访问层
 * 存放 MyBatis 配置文件 ， 包括映射器类、XML配置、XML映射文件
 */
/**
 * @author Administrator
 *
 */
package com.smartcommunity.mapper;