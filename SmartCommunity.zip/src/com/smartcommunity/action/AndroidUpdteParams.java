package com.smartcommunity.action;

public class AndroidUpdteParams {

	private String version;
	
	public String getVersion() {
		return version;
	}

	public void setVersion(String version) {
		this.version = version;
	}

}
