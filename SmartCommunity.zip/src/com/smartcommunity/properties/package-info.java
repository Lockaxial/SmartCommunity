/**
 * XML 文件配置所需要的属性放在这个包中
 */
/**
 * @author Administrator
 *
 */
package com.smartcommunity.properties;