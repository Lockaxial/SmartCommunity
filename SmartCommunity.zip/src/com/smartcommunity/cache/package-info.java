/**
 * 
 */
/**
 * @author Administrator
 *
 */
package com.smartcommunity.cache;