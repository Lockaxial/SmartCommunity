/**
 * 
 */
/**
 * @author Administrator
 *
 */
package com.smartcommunity.util;