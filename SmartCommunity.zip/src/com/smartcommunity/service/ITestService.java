package com.smartcommunity.service;

import java.util.List;

import net.sf.json.JSONObject;

import com.smartcommunity.pojo.TestPojo;


public interface ITestService {
	public com.smartcommunity.pojo.Roomowner getTestInfo();
}
