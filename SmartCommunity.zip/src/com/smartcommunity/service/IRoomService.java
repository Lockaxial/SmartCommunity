package com.smartcommunity.service;

public interface IRoomService {

}
