/**
 * 服务接口的实现
 */
/**
 * @author Administrator
 *
 */
package com.smartcommunity.service.impl;