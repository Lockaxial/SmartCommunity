package com.smartcommunity.service.impl;

import com.smartcommunity.service.IRoomService;

public class RoomServiceImpl implements IRoomService {

}
