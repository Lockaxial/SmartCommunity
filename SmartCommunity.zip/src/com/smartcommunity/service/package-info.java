/**
 * 服务接口
 */
/**
 * @author Administrator
 *
 */
package com.smartcommunity.service;