/**
 * 普通 java 对象，不包含业务逻辑
 */
/**
 * @author Administrator
 *
 */
package com.smartcommunity.pojo;