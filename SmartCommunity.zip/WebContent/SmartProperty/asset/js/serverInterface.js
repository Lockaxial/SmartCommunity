//查看报修信息
var requestUndoRepairMsg={
	url:"../../repair/listRepairInfoByPage.action",
	callbackMethod:"", 
	data:""
}

//查看已处理的报修信息
var requestFinishedRepairMsg={
	url:"../../repair/listRepairInfoByPage.action",
	callbackMethod:"", 
	data:""
}